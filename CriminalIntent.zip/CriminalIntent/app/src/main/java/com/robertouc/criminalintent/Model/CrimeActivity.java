package com.robertouc.criminalintent.Model;

import android.support.v4.app.Fragment;

import com.robertouc.criminalintent.SingleFragmentActivity;

public class CrimeActivity extends SingleFragmentActivity {


    public static final String EXTRA_CRIME_ID ="com.robertouc.criminalintent";

    @Override
    public Fragment createFragment() {
        return new CrimeFragment();
    }
}
